import org.apache.spark.sql.SparkSession
import java.io.{BufferedWriter, File, FileWriter}
import org.graphframes.GraphFrame
import org.apache.spark.sql.functions.{desc, lit}


object GraphX {
  def main(args: Array[String]): Unit = {

    if (args.length != 2) {
      println("Error.")
      println("Usage: InputDir OutputDir")
      return
    }

    val spark =
      SparkSession.builder()
        .appName("sparkX").getOrCreate()

    //Reading from Input file
    val sc = spark.sparkContext
    val df = spark.read.option("delimiter", ",").option("header", "true").csv(args(0))

    //Edges of the graph from the dataset
    val NetEdges = df.withColumnRenamed("InitialNode", "src").withColumnRenamed("FinalNode", "dst")

    //Vertices of the graph from the dataset
    val from_vertices = df.select("InitialNode").toDF("id")
    val to_vertices = df.select("FinalNode").toDF("id")
    val combine = from_vertices.join(to_vertices, Seq("id"), "outer")
    val NetVertices = combine.distinct.toDF

    val NetGraph = GraphFrame(NetVertices, NetEdges)
    NetGraph.cache()

    //Finding the top 5 nodes with the highest outdegree and find the count of the number of outgoing edges in each
    val outDeg = NetGraph.outDegrees
    outDeg.orderBy(desc("outDegree")).toDF().limit(5).rdd.saveAsTextFile(args(1) + "/outDegree")

    //Finding the top 5 nodes with the highest indegree and find the count of the number of incoming edges in each
    val inDeg = NetGraph.inDegrees
    inDeg.orderBy(desc("inDegree")).toDF().limit(5).rdd.saveAsTextFile(args(1) + "/inDegree")

    //Calculate PageRank for each of the nodes and output the top 5 nodes with the highest PageRank values. You are free to define the threshold parameter.
    val ranks = NetGraph.pageRank.resetProbability(0.15).maxIter(10).run()
    ranks.vertices.orderBy(desc("pagerank")).select("id", "pagerank").toDF().limit(5).rdd.saveAsTextFile(args(1) + "/pagerank")

    //Run the connected components algorithm on it and find the top 5 components with the largest number of nodes.
    spark.sparkContext.setCheckpointDir("/tmp/checkpoints")
    val cc = NetGraph.connectedComponents.run()
    cc.groupBy("component").count.orderBy(desc("count")).select("component","count").toDF().limit(5).rdd.saveAsTextFile(args(1) + "/connectedComponents")

    //Run the triangle counts algorithm on each of the vertices and output the top 5 vertices with the largest triangle count. In case of ties, you can randomly select the top 5 vertices.
    val TriangleCount = NetGraph.triangleCount.run()
    TriangleCount.orderBy(desc("count")).select("id", "count").toDF().limit(5).rdd.saveAsTextFile(args(1) + "/trianglecount")
  }
}