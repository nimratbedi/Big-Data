import java.util.Properties

import org.apache.log4j.{Level, Logger}
import twitter4j.conf.ConfigurationBuilder
import twitter4j.auth.OAuthAuthorization
import twitter4j.Status

import org.apache.spark.{SparkConf, SparkContext}

import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.twitter.TwitterUtils
import org.apache.spark.streaming.{Seconds, StreamingContext}

import org.apache.kafka.clients.producer.{KafkaProducer, ProducerConfig, ProducerRecord}

import SentimentAnalyzer.mainSentiment

object SentimentAnalysis {
  def main(args: Array[String]) {

    if (args.length < 2) {
      System.out.println("Usage: SentimentAnalysis <KafkaTopic> <keyword1> <keyword2> .....")
      return
    }

  
    if (!Logger.getRootLogger.getAllAppenders.hasMoreElements) {
      Logger.getRootLogger.setLevel(Level.WARN)
    }

    val topic = args(0).toString
    val keywords = args.slice(1, args.length)
    val kafkaBroker = "localhost:9092"

    val sparkConf = new SparkConf().setAppName("Tweets-Sentiment-Analysis")

    if (!sparkConf.contains("spark.master")) {
      sparkConf.setMaster("local[2]")
    }

    val sprktxt = new StreamingContext(sparkConf, Seconds(5))

    val cb = new ConfigurationBuilder
    cb.setDebugEnabled(true).setOAuthConsumerKey("O3wyMnJAQ4cTWlg2pwlj0lZOd")
      .setOAuthConsumerSecret("wEXmjAhjpxxX4CQsgxbwrp89qfNL6mmuuX0xKbceO0igTFaftk")
      .setOAuthAccessToken("1388230948404215817-17mlkzTfvuPiljC6pJEO5L6pMPLVQC")
      .setOAuthAccessTokenSecret("nyPbtmvoRh3DRvaPzr1TOOevGixpoBgkfQwApQEHz68Ov")

    val auth = new OAuthAuthorization(cb.build)

    val tweets: DStream[Status] = TwitterUtils.createStream(sprktxt, Some(auth), keywords)

    val sentiments: DStream[Int] =
      tweets.filter(x => x.getLang == "en").
        map(_.getText).
        map(tweetText => (mainSentiment(tweetText)))

    val sentimentText = Array("Very Negative", "Negative", "Neutral", "Positive", "Very Positive")
    // sending data to Kafka broker
    sentiments.foreachRDD( rdd => {
      rdd.foreachPartition( partition => {
        val props = new Properties()
        val bootstrap = "localhost:9092"
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBroker)
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer")
        props.put("bootstrap.servers", bootstrap)
        val producer = new KafkaProducer[String, String](props)
        partition.foreach( record => {
          val data = sentimentText(record)
          val message = new ProducerRecord[String, String](topic, null, data)
          producer.send(message)
        } )
        producer.close()
      })

    })

    sprktxt.start()
    sprktxt.awaitTermination()
  }
}

